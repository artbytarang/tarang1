import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Quote } from 'lucide-react';
const About = () => {
  return <>
      <Helmet>
        <title>The Artist - Tarang Singh | Art By Tarang Biography</title>
        <meta name="description" content="Meet Tarang Singh, a mixed-media artist. Discover the philosophy, creative process, and biography behind the unique abstract artwork at Art By Tarang." />
        <meta name="keywords" content="Tarang Singh, artist biography, Art By Tarang, creative process, abstract artist, contemporary artist, mixed media, art philosophy, female artist, art studio" />
      </Helmet>

      <div className="pt-20">
        {/* Biography Section */}
        <section className="py-20 bg-[#FFFEF9]">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid md:grid-cols-2 gap-12 items-start mb-16">
              <motion.div initial={{
              opacity: 0,
              x: -30
            }} whileInView={{
              opacity: 1,
              x: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.6
            }}>
                <img className="w-full h-[600px] object-cover shadow-2xl" alt="Artist Tarang Singh posing with golden tree artwork in the snow" src="https://horizons-cdn.hostinger.com/d4605bde-f0c9-4903-8ebf-9183fcc8ef1d/6b3e692c3ff3fa7d6eb71751cc911a54.jpg" />
              </motion.div>

              <motion.div initial={{
              opacity: 0,
              x: 30
            }} whileInView={{
              opacity: 1,
              x: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.6
            }} className="space-y-6">
                <div>
                  <span className="font-sans text-sm uppercase tracking-wider text-[#C9AB81] mb-4 block">
                    Biography
                  </span>
                  <h2 className="font-serif text-4xl font-light text-[#1A1A1A] mb-6">
                    Tarang Singh
                  </h2>
                </div>

                <p className="font-sans text-base text-gray-700 leading-relaxed">
                  Tarang Singh is a contemporary artist whose work transcends traditional 
                  boundaries, merging abstract expressionism with figurative elements to 
                  create deeply personal and universally resonant pieces.
                </p>

                <p className="font-sans text-base text-gray-700 leading-relaxed">
                  Born with an innate curiosity for color and form, Tarang developed a 
                  unique artistic language that speaks to the human experience. Her mixed-media 
                  approach incorporates acrylics, oils, and gold leaf, creating rich textural 
                  landscapes that invite prolonged contemplation.
                </p>

                <p className="font-sans text-base text-gray-700 leading-relaxed">
                  Drawing inspiration from both Eastern and Western artistic traditions, 
                  Tarang's work reflects a deep appreciation for minimalism, spirituality, 
                  and the subtle interplay between light and shadow. Each piece is meticulously 
                  crafted over weeks or months, layering meaning and texture until the 
                  artwork achieves its final, harmonious state.
                </p>

                <p className="font-sans text-base text-gray-700 leading-relaxed">Her works have been featured in private collections and curated exhibitions across the United States, with collectors drawn to the meditative quality and timeless elegance of her artistic vision. Tarang continues to push the boundaries of her practice, exploring new mediums and techniques while remaining deeply rooted in her core aesthetic philosophy.</p>
              </motion.div>
            </div>

            {/* Artist Quote */}
            <motion.div initial={{
            opacity: 0,
            y: 30
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.6
          }} className="bg-[#F5F5DC] p-12 md:p-16 relative">
              <Quote className="absolute top-8 left-8 w-12 h-12 text-[#C9AB81] opacity-30" />
              <blockquote className="relative z-10">
                <p className="font-serif text-2xl md:text-3xl font-light text-[#1A1A1A] text-center leading-relaxed mb-6 italic">
                  "Art is not about what you see, but about what you make others see. 
                  I create spaces for quiet reflection, where viewers can discover their 
                  own stories within the layers of paint and texture."
                </p>
                <p className="font-sans text-sm uppercase tracking-wider text-[#C9AB81] text-center">
                  — Tarang Singh
                </p>
              </blockquote>
            </motion.div>
          </div>
        </section>

        {/* Creative Philosophy */}
        <section className="py-20 bg-[#1A1A1A]">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div initial={{
            opacity: 0,
            y: 30
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.6
          }} className="text-center mb-12">
              <span className="font-sans text-sm uppercase tracking-wider text-[#C9AB81] mb-4 block">
                Philosophy
              </span>
              <h2 className="font-serif text-4xl md:text-5xl font-light text-[#F5F5DC] mb-8">
                Creative Vision
              </h2>
            </motion.div>

            <div className="grid md:grid-cols-2 gap-8">
              <motion.div initial={{
              opacity: 0,
              y: 20
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.5
            }} className="bg-[#2A2A2A] p-8">
                <h3 className="font-serif text-2xl font-light text-[#C9AB81] mb-4">
                  Process
                </h3>
                <p className="font-sans text-sm text-[#F5F5DC]/80 leading-relaxed">
                  Each artwork begins with a moment of inspiration—a fleeting emotion, 
                  a memory, or a philosophical question. Through layering, scraping, 
                  and rebuilding, the piece evolves organically, revealing its true 
                  nature over time.
                </p>
              </motion.div>

              <motion.div initial={{
              opacity: 0,
              y: 20
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.5,
              delay: 0.1
            }} className="bg-[#2A2A2A] p-8">
                <h3 className="font-serif text-2xl font-light text-[#C9AB81] mb-4">
                  Materials
                </h3>
                <p className="font-sans text-sm text-[#F5F5DC]/80 leading-relaxed">
                  Working primarily with acrylics, oils, and gold leaf on canvas, 
                  I embrace the unpredictability of mixed media. The tension between 
                  control and chaos creates unexpected beauty and depth in each piece.
                </p>
              </motion.div>

              <motion.div initial={{
              opacity: 0,
              y: 20
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.5,
              delay: 0.2
            }} className="bg-[#2A2A2A] p-8">
                <h3 className="font-serif text-2xl font-light text-[#C9AB81] mb-4">
                  Inspiration
                </h3>
                <p className="font-sans text-sm text-[#F5F5DC]/80 leading-relaxed">
                  Nature's subtle gradations, architectural forms, and the human 
                  condition all inform my work. I seek to capture the ephemeral—those 
                  quiet moments that slip away if not observed with intention.
                </p>
              </motion.div>

              <motion.div initial={{
              opacity: 0,
              y: 20
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.5,
              delay: 0.3
            }} className="bg-[#2A2A2A] p-8">
                <h3 className="font-serif text-2xl font-light text-[#C9AB81] mb-4">
                  Purpose
                </h3>
                <p className="font-sans text-sm text-[#F5F5DC]/80 leading-relaxed">
                  My goal is to create art that transcends trends and time, offering 
                  viewers a sanctuary from the noise of modern life. Each piece is an 
                  invitation to pause, breathe, and simply be.
                </p>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Studio Image */}
        <section className="py-20 bg-[#FFFEF9]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div initial={{
            opacity: 0,
            y: 30
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.6
          }}>
              <img className="w-full h-[500px] object-cover shadow-2xl" alt="Tarang Singh's art studio workspace" src="https://images.unsplash.com/photo-1640622299541-8c8ab8a098f3" />
            </motion.div>
          </div>
        </section>
      </div>
    </>;
};
export default About;