import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Minus } from 'lucide-react';
import ProductsList from '@/components/ProductsList';

const FaqItem = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border-b border-[#C9AB81]/30 last:border-0">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full py-6 flex items-center justify-between text-left focus:outline-none group"
      >
        <span className={`font-serif text-xl ${isOpen ? 'text-[#C9AB81]' : 'text-[#1A1A1A]'} group-hover:text-[#C9AB81] transition-colors`}>
          {question}
        </span>
        <span className="ml-4 text-[#C9AB81]">
          {isOpen ? <Minus size={20} /> : <Plus size={20} />}
        </span>
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="overflow-hidden"
          >
            <p className="font-sans text-gray-600 pb-6 pr-12 leading-relaxed">
              {answer}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const Gallery = () => {
  const faqs = [
    {
      question: "Do you ship internationally?",
      answer: "Yes, I ship artwork worldwide. International shipping costs are calculated at checkout based on your location and the size of the artwork. Please note that international buyers are responsible for any customs duties or import taxes that may apply."
    },
    {
      question: "How is the artwork packaged?",
      answer: "Great care is taken to ensure your artwork arrives safely. Paintings are wrapped in acid-free paper, protected with bubble wrap, and shipped in sturdy, reinforced boxes. Large canvas works may be removed from their stretcher bars and shipped rolled in a tube to ensure maximum safety and lower shipping costs."
    },
    {
      question: "Do paintings come with a Certificate of Authenticity?",
      answer: "Absolutely. Every original painting purchased from the gallery comes with a hand-signed Certificate of Authenticity, verifying the artwork's provenance and value."
    },
    {
      question: "Are the paintings ready to hang?",
      answer: "Most canvas paintings are gallery-wrapped (painted on the sides) and ready to hang. Works on paper typically require framing. Please check the specific product description for details on whether a piece is framed or unframed."
    },
    {
      question: "How should I care for my painting?",
      answer: "To preserve your artwork, avoid exposing it to direct sunlight, extreme temperatures, or high humidity. Dust lightly with a soft, dry cloth or a clean artist's brush. Never use water or cleaning products on the surface of the painting."
    }
  ];

  return (
    <>
      <Helmet>
        <title>Online Art Gallery | Buy Original Paintings - Art By Tarang</title>
        <meta name="description" content="Explore the Art By Tarang gallery. Shop curated original abstract paintings, mixed media works, and limited edition prints by Tarang Singh. Secure international shipping." />
        <meta name="keywords" content="art gallery, buy paintings, online art shop, original artwork for sale, abstract art, Tarang Singh gallery, contemporary art collection, fine art shop, wall decor" />
      </Helmet>

      <div className="pt-20">
        {/* Hero Section */}
        <section className="relative h-[40vh] flex items-center justify-center overflow-hidden bg-[#1A1A1A]">
          <div className="relative z-10 max-w-4xl mx-auto px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <span className="font-sans text-sm uppercase tracking-wider text-[#C9AB81] mb-4 block">
                Portfolio & Collection
              </span>
              <h1 className="font-serif text-5xl md:text-6xl font-light text-[#F5F5DC] mb-4">
                Gallery
              </h1>
              <p className="font-sans text-lg text-[#F5F5DC]/80">
                A complete archive of available works and sold collector's pieces.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Products Grid */}
        <section className="py-20 bg-[#FFFEF9]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ProductsList />
          </div>
        </section>

        {/* Info Section */}
        <section className="py-16 bg-[#F5F5DC]">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="font-serif text-3xl font-light text-[#1A1A1A] mb-6">
              Acquisition Information
            </h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div>
                <h3 className="font-sans text-sm uppercase tracking-wider text-[#C9AB81] mb-2">
                  Authenticity
                </h3>
                <p className="font-sans text-sm text-gray-600">
                  Each artwork includes a signed certificate of authenticity
                </p>
              </div>
              <div>
                <h3 className="font-sans text-sm uppercase tracking-wider text-[#C9AB81] mb-2">
                  Shipping
                </h3>
                <p className="font-sans text-sm text-gray-600">
                  Fully insured shipping with professional packaging
                </p>
              </div>
              <div>
                <h3 className="font-sans text-sm uppercase tracking-wider text-[#C9AB81] mb-2">
                  Returns
                </h3>
                <p className="font-sans text-sm text-gray-600">
                  View our Returns & Shipping policy for details.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-20 bg-white">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <span className="font-sans text-sm uppercase tracking-wider text-[#C9AB81] mb-3 block">
                Common Questions
              </span>
              <h2 className="font-serif text-3xl md:text-4xl font-light text-[#1A1A1A]">
                Frequently Asked Questions
              </h2>
            </div>
            
            <div className="bg-white rounded-lg">
              {faqs.map((faq, index) => (
                <FaqItem 
                  key={index}
                  question={faq.question}
                  answer={faq.answer}
                />
              ))}
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Gallery;