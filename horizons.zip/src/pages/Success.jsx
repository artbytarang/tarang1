import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Success = () => {
  return (
    <>
      <Helmet>
        <title>Order Successful - Art By Tarang</title>
        <meta name="description" content="Thank you for your purchase." />
      </Helmet>

      <div className="pt-32 pb-20 bg-[#FFFEF9] min-h-screen flex items-center justify-center">
        <div className="max-w-xl mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <CheckCircle className="w-24 h-24 text-[#C9AB81] mx-auto mb-6" />
            <span className="font-sans text-sm uppercase tracking-wider text-[#C9AB81] mb-4 block">
              Payment Successful
            </span>
            <h1 className="font-serif text-5xl font-light text-[#1A1A1A] mb-6">
              Thank You!
            </h1>
            <p className="font-sans text-lg text-gray-600 leading-relaxed mb-8">
              Your order has been successfully placed. You will receive a confirmation email shortly with your order details and tracking information.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/gallery">
                <Button className="bg-[#1A1A1A] hover:bg-[#C9AB81] hover:text-[#1A1A1A] text-[#F5F5DC] font-sans uppercase tracking-wider px-8 py-6">
                  Continue Browsing
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default Success;