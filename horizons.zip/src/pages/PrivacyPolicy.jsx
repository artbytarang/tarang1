import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';

const PrivacyPolicy = () => {
  useEffect(() => {
    // Scroll to the top of the page when the component mounts
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <Helmet>
        <title>Privacy Policy - Art By Tarang</title>
        <meta name="description" content="Privacy Policy for Art By Tarang. Learn how we collect, use, and protect your personal information." />
      </Helmet>

      <div className="pt-20 bg-[#1E1E1E] min-h-screen text-[#F5F5DC]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="font-serif text-5xl md:text-6xl font-light text-[#F5F5DC] mb-8">
              Privacy Policy
            </h1>

            <div className="prose prose-lg max-w-none">
              <p className="font-sans text-sm text-gray-400 mb-8">
                Last Updated: December 27, 2025
              </p>

              <section className="mb-8">
                <h2 className="font-serif text-2xl font-light text-[#F5F5DC] mb-4">
                  Introduction
                </h2>
                <p className="font-sans text-base text-[#F5F5DC] leading-relaxed mb-4">
                  Art By Tarang LLC ("we," "our," or "us") respects your privacy and is committed to protecting your personal data. 
                  This privacy policy explains how we collect, use, and safeguard your information when you visit our website 
                  or make a purchase.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="font-serif text-2xl font-light text-[#F5F5DC] mb-4">
                  Information We Collect
                </h2>
                <p className="font-sans text-base text-[#F5F5DC] leading-relaxed mb-4">
                  We may collect the following types of information:
                </p>
                <ul className="font-sans text-base text-[#F5F5DC] leading-relaxed list-disc pl-6 space-y-2">
                  <li>Personal identification information (name, email address, phone number)</li>
                  <li>Billing and shipping addresses</li>
                  <li>Payment information (processed securely through third-party payment processors)</li>
                  <li>Communication preferences and correspondence</li>
                  <li>Website usage data and analytics</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="font-serif text-2xl font-light text-[#F5F5DC] mb-4">
                  How We Use Your Information
                </h2>
                <p className="font-sans text-base text-[#F5F5DC] leading-relaxed mb-4">
                  We use your information to:
                </p>
                <ul className="font-sans text-base text-[#F5F5DC] leading-relaxed list-disc pl-6 space-y-2">
                  <li>Process and fulfill your orders</li>
                  <li>Communicate with you about your purchases or inquiries</li>
                  <li>Send promotional emails (only with your consent)</li>
                  <li>Improve our website and services</li>
                  <li>Prevent fraud and enhance security</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="font-serif text-2xl font-light text-[#F5F5DC] mb-4">
                  Data Security
                </h2>
                <p className="font-sans text-base text-[#F5F5DC] leading-relaxed mb-4">
                  We implement appropriate technical and organizational measures to protect your personal data against 
                  unauthorized access, alteration, disclosure, or destruction. Payment information is processed through 
                  secure, PCI-compliant payment gateways.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="font-serif text-2xl font-light text-[#F5F5DC] mb-4">
                  Cookies
                </h2>
                <p className="font-sans text-base text-[#F5F5DC] leading-relaxed mb-4">
                  Our website uses cookies to enhance your browsing experience and analyze site traffic. You can control 
                  cookie preferences through your browser settings.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="font-serif text-2xl font-light text-[#F5F5DC] mb-4">
                  Your Rights
                </h2>
                <p className="font-sans text-base text-[#F5F5DC] leading-relaxed mb-4">
                  You have the right to:
                </p>
                <ul className="font-sans text-base text-[#F5F5DC] leading-relaxed list-disc pl-6 space-y-2">
                  <li>Access your personal data</li>
                  <li>Correct inaccurate data</li>
                  <li>Request deletion of your data</li>
                  <li>Opt-out of marketing communications</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="font-serif text-2xl font-light text-[#F5F5DC] mb-4">
                  Contact Us
                </h2>
                <p className="font-sans text-base text-[#F5F5DC] leading-relaxed mb-4">
                  If you have questions about this Privacy Policy or wish to exercise your rights, please contact us at:
                </p>
                <p className="font-sans text-base text-[#F5F5DC] leading-relaxed">
                  Email: artbytarang@gmail.com
                </p>
              </section>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default PrivacyPolicy;