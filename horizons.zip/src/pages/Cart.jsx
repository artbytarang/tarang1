import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Trash2, Plus, Minus, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/context/CartContext';

const Cart = () => {
  const { cart, removeFromCart, updateQuantity, getCartTotal } = useCart();

  if (cart.length === 0) {
    return (
      <>
        <Helmet>
          <title>Shopping Cart - Art By Tarang</title>
          <meta name="description" content="Your shopping cart for Art By Tarang original artworks." />
        </Helmet>

        <div className="pt-20 bg-[#FFFEF9] min-h-screen">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
            <h1 className="font-serif text-4xl font-light text-[#1A1A1A] mb-4">
              Your Cart is Empty
            </h1>
            <p className="font-sans text-base text-gray-600 mb-8">
              Explore our collection and add artworks to your cart
            </p>
            <Link to="/shop">
              <Button className="bg-[#1A1A1A] hover:bg-[#2A2A2A] text-[#F5F5DC] font-sans uppercase tracking-wider">
                Continue Shopping
              </Button>
            </Link>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>Shopping Cart - Art By Tarang</title>
        <meta name="description" content="Review your selected artworks and proceed to checkout." />
      </Helmet>

      <div className="pt-20 bg-[#FFFEF9] min-h-screen">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <Link to="/shop">
            <Button variant="ghost" className="mb-8 text-gray-600 hover:text-[#1A1A1A]">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Continue Shopping
            </Button>
          </Link>

          <h1 className="font-serif text-4xl md:text-5xl font-light text-[#1A1A1A] mb-8">
            Shopping Cart
          </h1>

          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              {cart.map((item) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white p-6 shadow-md flex flex-col sm:flex-row gap-6"
                >
                  <img 
                    className="w-full sm:w-32 h-32 object-cover"
                    alt={item.title}
                   src="https://images.unsplash.com/photo-1595872018818-97555653a011" />

                  <div className="flex-1">
                    <h3 className="font-serif text-xl font-light text-[#1A1A1A] mb-2">
                      {item.title}
                    </h3>
                    <p className="font-sans text-sm text-gray-600 mb-2">
                      {item.medium}
                    </p>
                    <p className="font-sans text-sm text-gray-500 mb-4">
                      {item.dimensions}
                    </p>
                    <div className="flex items-center gap-4">
                      <div className="flex items-center border border-gray-300">
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="p-2 hover:bg-gray-100 transition-colors"
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                        <span className="px-4 font-sans text-sm">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="p-2 hover:bg-gray-100 transition-colors"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="text-red-600 hover:text-red-800 transition-colors"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>

                  <div className="text-right">
                    <p className="font-sans text-xl text-[#C9AB81] font-medium">
                      ${(item.price * item.quantity).toLocaleString()}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="lg:col-span-1">
              <div className="bg-white p-6 shadow-md sticky top-24">
                <h2 className="font-serif text-2xl font-light text-[#1A1A1A] mb-6">
                  Order Summary
                </h2>

                <div className="space-y-4 mb-6">
                  <div className="flex justify-between">
                    <span className="font-sans text-sm text-gray-600">Subtotal</span>
                    <span className="font-sans text-sm text-gray-900">
                      ${getCartTotal().toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-sans text-sm text-gray-600">Shipping</span>
                    <span className="font-sans text-sm text-gray-900">Calculated at checkout</span>
                  </div>
                  <div className="border-t border-gray-200 pt-4">
                    <div className="flex justify-between">
                      <span className="font-sans text-lg font-medium text-[#1A1A1A]">Total</span>
                      <span className="font-sans text-lg font-medium text-[#C9AB81]">
                        ${getCartTotal().toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>

                <Link to="/checkout">
                  <Button className="w-full bg-[#C9AB81] hover:bg-[#B8956F] text-[#1A1A1A] font-sans uppercase tracking-wider py-6 mb-4">
                    Proceed to Checkout
                  </Button>
                </Link>

                <div className="bg-[#F5F5DC] p-4 text-center">
                  <p className="font-sans text-xs text-gray-600">
                    Secure checkout with SSL encryption
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Cart;