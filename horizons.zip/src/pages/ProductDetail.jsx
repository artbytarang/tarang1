import React, { useState, useEffect, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Loader2, ArrowLeft, AlertCircle, Tag, ShoppingCart, Info } from 'lucide-react';
import { getProduct, getProductQuantities, formatCurrency } from '@/api/EcommerceApi';
import { useCart } from '@/hooks/useCart';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';

const placeholderImage = "https://images.unsplash.com/photo-1579783902614-a3fb39279c0b?q=80&w=1000&auto=format&fit=crop";

const VALID_DISCOUNT_CODES = {
  'WELCOME20': 0.20,
  'ART10': 0.10,
  'SAVE5': 0.05
};

const ProductDetail = () => {
  const { id } = useParams();
  const { addToCart } = useCart();
  const { toast } = useToast();
  
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  const [selectedVariant, setSelectedVariant] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [activeImage, setActiveImage] = useState(null);
  
  // Discount Logic
  const [discountCode, setDiscountCode] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState(null); // { code: string, percent: number }

  useEffect(() => {
    const fetchProductData = async () => {
      try {
        setLoading(true);
        const fetchedProduct = await getProduct(id);
        
        // Fetch real-time inventory
        const quantities = await getProductQuantities({
          fields: 'inventory_quantity',
          product_ids: [fetchedProduct.id]
        });

        // Merge inventory into variants
        const variantsWithInventory = fetchedProduct.variants.map(v => {
          const qtyData = quantities.variants.find(q => q.id === v.id);
          return {
            ...v,
            inventory_quantity: qtyData ? qtyData.inventory_quantity : v.inventory_quantity
          };
        });

        const fullProduct = { ...fetchedProduct, variants: variantsWithInventory };
        
        setProduct(fullProduct);
        if (fullProduct.variants.length > 0) {
          setSelectedVariant(fullProduct.variants[0]);
        }
        setActiveImage(fullProduct.image || placeholderImage);
      } catch (err) {
        console.error(err);
        setError("Unable to load artwork details.");
      } finally {
        setLoading(false);
      }
    };

    fetchProductData();
    window.scrollTo(0, 0);
  }, [id]);

  // Handle Image Selection
  const handleImageClick = (url) => {
    setActiveImage(url);
  };

  // Determine Product Status
  const status = useMemo(() => {
    if (!product) return 'Loading';
    const allSoldOut = product.variants.every(v => 
      v.manage_inventory && v.inventory_quantity !== null && v.inventory_quantity <= 0
    );
    if (allSoldOut) return 'Sold Out';
    if (!product.purchasable) return 'Unavailable';
    return 'Available';
  }, [product]);

  // Calculate Prices with Discount
  const priceCalculation = useMemo(() => {
    if (!selectedVariant) return { original: 0, current: 0, formatted: '' };

    const basePrice = selectedVariant.sale_price_in_cents ?? selectedVariant.price_in_cents;
    let finalPrice = basePrice;
    let savedAmount = 0;

    if (appliedDiscount) {
      const discountAmount = Math.round(basePrice * appliedDiscount.percent);
      finalPrice = basePrice - discountAmount;
      savedAmount = discountAmount;
    }

    return {
      base: basePrice,
      final: finalPrice,
      saved: savedAmount,
      currency: selectedVariant.currency_info,
      isDiscounted: !!appliedDiscount || (selectedVariant.sale_price_in_cents !== null),
      hasCoupon: !!appliedDiscount
    };
  }, [selectedVariant, appliedDiscount]);

  const handleApplyDiscount = () => {
    if (!discountCode.trim()) return;

    const normalizedCode = discountCode.trim().toUpperCase();
    const discountPercent = VALID_DISCOUNT_CODES[normalizedCode];

    if (discountPercent) {
      setAppliedDiscount({ code: normalizedCode, percent: discountPercent });
      toast({
        title: "Discount Applied!",
        description: `${normalizedCode} applied. You save ${(discountPercent * 100).toFixed(0)}% on this item.`,
        variant: "default",
      });
    } else {
      setAppliedDiscount(null);
      toast({
        title: "Invalid Code",
        description: "The discount code you entered is not valid.",
        variant: "destructive",
      });
    }
  };

  const handleClearDiscount = () => {
    setAppliedDiscount(null);
    setDiscountCode('');
    toast({
      description: "Discount removed.",
    });
  };

  const handleAddToCart = () => {
    if (!selectedVariant) return;

    // Check inventory for specific variant
    if (selectedVariant.manage_inventory && 
        selectedVariant.inventory_quantity !== null && 
        selectedVariant.inventory_quantity < quantity) {
      toast({
        title: "Insufficient Stock",
        description: `Only ${selectedVariant.inventory_quantity} available.`,
        variant: "destructive"
      });
      return;
    }

    addToCart(product, selectedVariant.id, quantity);
    toast({
      title: "Added to Cart",
      description: `${product.title} has been added to your collection.`,
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#FFFEF9]">
        <Loader2 className="h-12 w-12 text-[#C9AB81] animate-spin" />
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="min-h-screen pt-24 px-4 text-center bg-[#FFFEF9]">
         <AlertCircle className="h-12 w-12 text-red-400 mx-auto mb-4" />
         <h2 className="font-serif text-2xl text-[#1A1A1A] mb-2">Artwork Not Found</h2>
         <p className="font-sans text-gray-600 mb-8">{error || "The artwork you are looking for does not exist."}</p>
         <Link to="/gallery">
            <Button variant="outline">Back to Gallery</Button>
         </Link>
      </div>
    );
  }

  const isSoldOut = status === 'Sold Out';
  const isUnavailable = status === 'Unavailable';

  return (
    <div className="min-h-screen bg-[#FFFEF9] pt-24 pb-16">
       <Helmet>
        <title>{product.title} | Art By Tarang</title>
        <meta name="description" content={product.description?.replace(/<[^>]*>?/gm, '').substring(0, 160)} />
      </Helmet>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Link to="/gallery" className="inline-flex items-center text-gray-500 hover:text-[#C9AB81] transition-colors mb-8 group">
          <ArrowLeft className="mr-2 h-4 w-4 group-hover:-translate-x-1 transition-transform" />
          Back to Gallery
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
          {/* Left Column: Images */}
          <div className="space-y-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="relative aspect-square bg-gray-100 overflow-hidden shadow-xl"
            >
              <img 
                src={activeImage} 
                alt={product.title} 
                className={`w-full h-full object-cover ${isSoldOut ? 'grayscale opacity-90' : ''}`}
              />
              {isSoldOut && (
                 <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                    <span className="bg-[#1A1A1A] text-[#F5F5DC] px-8 py-3 text-2xl font-serif uppercase tracking-widest shadow-lg transform -rotate-12 border border-[#F5F5DC]">
                      Sold Out
                    </span>
                 </div>
              )}
            </motion.div>

            {/* Thumbnails */}
            {product.images.length > 1 && (
              <div className="grid grid-cols-4 sm:grid-cols-5 gap-4">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleImageClick(img.url)}
                    className={`aspect-square overflow-hidden border-2 transition-all ${activeImage === img.url ? 'border-[#C9AB81]' : 'border-transparent hover:border-[#C9AB81]/50'}`}
                  >
                    <img src={img.url} alt={`${product.title} view ${idx + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right Column: Details */}
          <div className="flex flex-col">
            <h1 className="font-serif text-4xl md:text-5xl text-[#1A1A1A] mb-2">{product.title}</h1>
            {product.subtitle && (
              <p className="font-sans text-xl text-gray-500 mb-6 font-light">{product.subtitle}</p>
            )}

            {/* Price Display */}
            <div className="mb-8 border-b border-[#C9AB81]/20 pb-8">
               {isSoldOut ? (
                 <p className="text-2xl text-[#C9AB81] font-serif italic">Sold</p>
               ) : (
                 <div className="flex flex-col items-start gap-2">
                    <div className="flex items-baseline gap-4">
                      {/* Final Price */}
                      <span className="text-3xl font-serif text-[#1A1A1A]">
                        {formatCurrency(priceCalculation.final, priceCalculation.currency)}
                      </span>
                      
                      {/* Original Price (if discounted) */}
                      {(priceCalculation.hasCoupon || (selectedVariant?.sale_price_in_cents !== null)) && (
                        <span className="text-lg text-gray-400 line-through font-sans">
                          {formatCurrency(priceCalculation.base, priceCalculation.currency)}
                        </span>
                      )}
                    </div>
                    
                    {/* Discount Badge */}
                    {priceCalculation.hasCoupon && (
                      <motion.div 
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="flex items-center gap-2 text-[#C9AB81] text-sm font-medium bg-[#C9AB81]/10 px-3 py-1 rounded-full"
                      >
                         <Tag size={14} />
                         <span>
                           Code {appliedDiscount.code}: {(appliedDiscount.percent * 100).toFixed(0)}% Off
                         </span>
                      </motion.div>
                    )}
                 </div>
               )}
            </div>

            {/* Discount Code Input */}
            {!isSoldOut && !isUnavailable && (
              <div className="mb-8 bg-gray-50 p-6 rounded-lg border border-gray-100">
                <label className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-3 block">
                  Have a Promo Code?
                </label>
                <div className="flex gap-2">
                  <Input 
                    placeholder="Enter code (e.g. WELCOME20)" 
                    value={discountCode}
                    onChange={(e) => setDiscountCode(e.target.value)}
                    disabled={!!appliedDiscount}
                    className="bg-white"
                  />
                  {appliedDiscount ? (
                     <Button variant="outline" onClick={handleClearDiscount} className="whitespace-nowrap border-red-200 text-red-500 hover:bg-red-50 hover:text-red-600">
                        Remove
                     </Button>
                  ) : (
                    <Button onClick={handleApplyDiscount} disabled={!discountCode} className="whitespace-nowrap bg-[#1A1A1A] hover:bg-[#C9AB81] text-white">
                        Apply
                    </Button>
                  )}
                </div>
                {appliedDiscount && (
                   <p className="text-xs text-gray-500 mt-2 flex items-center gap-1">
                     <Info size={12} />
                     Discount applied to display price.
                   </p>
                )}
              </div>
            )}

            {/* Variant Selector */}
            {product.variants.length > 1 && (
               <div className="mb-6">
                 <label className="text-sm font-medium text-gray-900 mb-2 block">Select Option</label>
                 <select 
                    className="w-full p-3 border border-gray-200 rounded-md bg-white focus:outline-none focus:border-[#C9AB81] font-sans"
                    value={selectedVariant?.id || ''}
                    onChange={(e) => {
                      const v = product.variants.find(v => v.id === e.target.value);
                      setSelectedVariant(v);
                    }}
                 >
                   {product.variants.map(v => (
                     <option key={v.id} value={v.id}>
                       {v.title} {v.inventory_quantity !== null && v.inventory_quantity <= 0 ? '(Out of Stock)' : ''}
                     </option>
                   ))}
                 </select>
               </div>
            )}

            {/* Add to Cart Actions */}
            <div className="mt-auto">
               {isSoldOut || isUnavailable ? (
                 <Button disabled className="w-full py-6 text-lg bg-gray-200 text-gray-500 cursor-not-allowed">
                    {status === 'Unavailable' ? 'Currently Unavailable' : 'Sold Out'}
                 </Button>
               ) : (
                 <div className="flex flex-col gap-4">
                   <div className="flex gap-4">
                      {/* Quantity Selector - Optional, keeping simple for art */}
                      {/* <div className="w-24">...</div> */} 
                      
                      <Button 
                        onClick={handleAddToCart}
                        className="flex-1 py-6 text-lg bg-[#C9AB81] hover:bg-[#1A1A1A] text-[#1A1A1A] hover:text-[#F5F5DC] transition-colors"
                        disabled={!selectedVariant || (selectedVariant.manage_inventory && selectedVariant.inventory_quantity <= 0)}
                      >
                         <ShoppingCart className="mr-2 h-5 w-5" />
                         Add to Cart
                      </Button>
                   </div>
                   <p className="text-xs text-gray-500 text-center">
                     Secure checkout powered by Hostinger.
                   </p>
                 </div>
               )}
            </div>

            {/* Product Description */}
            <div className="mt-12 prose prose-stone max-w-none">
               <h3 className="font-serif text-2xl text-[#1A1A1A] mb-4">About the Artwork</h3>
               <div dangerouslySetInnerHTML={{ __html: product.description }} className="font-sans text-gray-600 leading-relaxed" />
            </div>

            {/* Additional Info Accordion style could go here */}
            {product.additional_info && product.additional_info.length > 0 && (
              <div className="mt-8 border-t border-gray-200 pt-8 space-y-6">
                 {product.additional_info.map(info => (
                   <div key={info.id}>
                      <h4 className="font-medium text-gray-900 mb-2">{info.title}</h4>
                      <div dangerouslySetInnerHTML={{ __html: info.description }} className="text-sm text-gray-600" />
                   </div>
                 ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;