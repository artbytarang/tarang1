import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { CreditCard, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/context/CartContext';
import { toast } from '@/components/ui/use-toast';

const Checkout = () => {
  const { cart, getCartTotal, clearCart } = useCart();
  const [formData, setFormData] = useState({
    email: '',
    firstName: '',
    lastName: '',
    address: '',
    city: '',
    postalCode: '',
    country: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    toast({
      title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <>
      <Helmet>
        <title>Checkout - Art By Tarang</title>
        <meta name="description" content="Complete your purchase of original artwork from Art By Tarang." />
      </Helmet>

      <div className="pt-20 bg-[#FFFEF9] min-h-screen">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h1 className="font-serif text-4xl md:text-5xl font-light text-[#1A1A1A] mb-8 text-center">
            Checkout
          </h1>

          <div className="grid lg:grid-cols-2 gap-12">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
            >
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <h2 className="font-serif text-2xl font-light text-[#1A1A1A] mb-4">
                    Contact Information
                  </h2>
                  <input
                    type="email"
                    name="email"
                    placeholder="Email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 focus:border-[#C9AB81] focus:outline-none transition-colors font-sans text-sm"
                  />
                </div>

                <div>
                  <h2 className="font-serif text-2xl font-light text-[#1A1A1A] mb-4">
                    Shipping Address
                  </h2>
                  <div className="grid md:grid-cols-2 gap-4 mb-4">
                    <input
                      type="text"
                      name="firstName"
                      placeholder="First Name"
                      value={formData.firstName}
                      onChange={handleChange}
                      required
                      className="px-4 py-3 border border-gray-300 focus:border-[#C9AB81] focus:outline-none transition-colors font-sans text-sm"
                    />
                    <input
                      type="text"
                      name="lastName"
                      placeholder="Last Name"
                      value={formData.lastName}
                      onChange={handleChange}
                      required
                      className="px-4 py-3 border border-gray-300 focus:border-[#C9AB81] focus:outline-none transition-colors font-sans text-sm"
                    />
                  </div>
                  <input
                    type="text"
                    name="address"
                    placeholder="Address"
                    value={formData.address}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 focus:border-[#C9AB81] focus:outline-none transition-colors font-sans text-sm mb-4"
                  />
                  <div className="grid md:grid-cols-2 gap-4">
                    <input
                      type="text"
                      name="city"
                      placeholder="City"
                      value={formData.city}
                      onChange={handleChange}
                      required
                      className="px-4 py-3 border border-gray-300 focus:border-[#C9AB81] focus:outline-none transition-colors font-sans text-sm"
                    />
                    <input
                      type="text"
                      name="postalCode"
                      placeholder="Postal Code"
                      value={formData.postalCode}
                      onChange={handleChange}
                      required
                      className="px-4 py-3 border border-gray-300 focus:border-[#C9AB81] focus:outline-none transition-colors font-sans text-sm"
                    />
                  </div>
                  <input
                    type="text"
                    name="country"
                    placeholder="Country"
                    value={formData.country}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 focus:border-[#C9AB81] focus:outline-none transition-colors font-sans text-sm mt-4"
                  />
                </div>

                <div>
                  <h2 className="font-serif text-2xl font-light text-[#1A1A1A] mb-4">
                    Payment Method
                  </h2>
                  <div className="bg-[#F5F5DC] p-6 border border-gray-300">
                    <div className="flex items-center mb-4">
                      <CreditCard className="w-5 h-5 text-[#C9AB81] mr-2" />
                      <span className="font-sans text-sm text-gray-700">Credit / Debit Card</span>
                    </div>
                    <div className="space-y-4">
                      <input
                        type="text"
                        placeholder="Card Number"
                        className="w-full px-4 py-3 border border-gray-300 focus:border-[#C9AB81] focus:outline-none transition-colors font-sans text-sm"
                      />
                      <div className="grid grid-cols-2 gap-4">
                        <input
                          type="text"
                          placeholder="MM / YY"
                          className="px-4 py-3 border border-gray-300 focus:border-[#C9AB81] focus:outline-none transition-colors font-sans text-sm"
                        />
                        <input
                          type="text"
                          placeholder="CVV"
                          className="px-4 py-3 border border-gray-300 focus:border-[#C9AB81] focus:outline-none transition-colors font-sans text-sm"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <Button 
                  type="submit"
                  className="w-full bg-[#C9AB81] hover:bg-[#B8956F] text-[#1A1A1A] font-sans uppercase tracking-wider py-6 text-base"
                >
                  <Lock className="w-4 h-4 mr-2" />
                  Complete Order
                </Button>

                <div className="text-center">
                  <p className="font-sans text-xs text-gray-600">
                    Your payment information is secure and encrypted
                  </p>
                </div>
              </form>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="bg-white p-6 shadow-md sticky top-24">
                <h2 className="font-serif text-2xl font-light text-[#1A1A1A] mb-6">
                  Order Summary
                </h2>

                <div className="space-y-4 mb-6">
                  {cart.map((item) => (
                    <div key={item.id} className="flex justify-between pb-4 border-b border-gray-200">
                      <div className="flex-1">
                        <p className="font-sans text-sm text-gray-900">{item.title}</p>
                        <p className="font-sans text-xs text-gray-600">Qty: {item.quantity}</p>
                      </div>
                      <p className="font-sans text-sm text-gray-900">
                        ${(item.price * item.quantity).toLocaleString()}
                      </p>
                    </div>
                  ))}
                </div>

                <div className="space-y-4 mb-6">
                  <div className="flex justify-between">
                    <span className="font-sans text-sm text-gray-600">Subtotal</span>
                    <span className="font-sans text-sm text-gray-900">
                      ${getCartTotal().toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-sans text-sm text-gray-600">Shipping</span>
                    <span className="font-sans text-sm text-gray-900">Free</span>
                  </div>
                  <div className="border-t border-gray-200 pt-4">
                    <div className="flex justify-between">
                      <span className="font-sans text-lg font-medium text-[#1A1A1A]">Total</span>
                      <span className="font-sans text-lg font-medium text-[#C9AB81]">
                        ${getCartTotal().toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Checkout;