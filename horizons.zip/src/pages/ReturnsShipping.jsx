import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Package, Truck } from 'lucide-react';

const ReturnsShipping = () => {
  useEffect(() => {
    // Scroll to the top of the page when the component mounts
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <Helmet>
        <title>Returns & Shipping Policy - Art By Tarang</title>
        <meta name="description" content="Learn about our shipping methods, delivery times, and return policy for Art By Tarang original artworks." />
        <meta name="keywords" content="art returns, art shipping, shipping policy, return policy, art by tarang shipping, damaged art, order cancellation" />
      </Helmet>

      <div className="pt-20 bg-[#1E1E1E] min-h-screen text-[#F5F5DC]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="font-serif text-5xl md:text-6xl font-light text-[#F5F5DC] mb-8">
              Returns & Shipping
            </h1>

            <div className="grid md:grid-cols-2 gap-8 mb-12"> 
              <div className="text-center p-6 bg-white shadow-md">
                <Package className="w-12 h-12 text-[#C9AB81] mx-auto mb-4" />
                <h3 className="font-serif text-xl font-light text-[#1A1A1A] mb-2">
                  Professional Packaging
                </h3>
                <p className="font-sans text-sm text-gray-600">
                  Museum-quality packaging materials
                </p>
              </div>

              <div className="text-center p-6 bg-white shadow-md">
                <Truck className="w-12 h-12 text-[#C9AB81] mx-auto mb-4" />
                <h3 className="font-serif text-xl font-light text-[#1A1A1A] mb-2">
                  Insured Shipping
                </h3>
                <p className="font-sans text-sm text-gray-600">
                  Fully insured during transit
                </p>
              </div>
            </div>

            <div className="prose prose-lg max-w-none">
              <section className="mb-8">
                <h2 className="font-serif text-2xl font-light text-[#F5F5DC] mb-4">
                  Shipping Policy
                </h2>
                
                <h3 className="font-sans text-lg font-medium text-[#C9AB81] mb-3 mt-6">
                  Sales Region
                </h3>
                <p className="font-sans text-base text-[#F5F5DC] leading-relaxed mb-4">
                  Paintings are currently available for sale only in North America regions. We appreciate your understanding.
                </p>

                <h3 className="font-sans text-lg font-medium text-[#C9AB81] mb-3 mt-6">
                  Domestic Shipping (United States)
                </h3>
                <ul className="font-sans text-base text-[#F5F5DC] leading-relaxed list-disc pl-6 space-y-2">
                  <li>Free shipping on all original artwork orders</li>
                  <li>Standard delivery: 5-7 business days</li>
                  <li>Expedited shipping available upon request (additional fees apply)</li>
                  <li>Tracking information provided for all shipments</li>
                </ul>

                <h3 className="font-sans text-lg font-medium text-[#C9AB81] mb-3 mt-6">
                  International Shipping
                </h3>
                <ul className="font-sans text-base text-[#F5F5DC] leading-relaxed list-disc pl-6 space-y-2">
                  <li>Not available outside of North America.</li>
                  <li>Customers responsible for customs duties and taxes for shipments within North America where applicable.</li>
                </ul>

                <h3 className="font-sans text-lg font-medium text-[#C9AB81] mb-3 mt-6">
                  Packaging Standards
                </h3>
                <p className="font-sans text-base text-[#F5F5DC] leading-relaxed mb-4">
                  Every artwork is carefully packaged using museum-quality materials:
                </p>
                <ul className="font-sans text-base text-[#F5F5DC] leading-relaxed list-disc pl-6 space-y-2">
                  <li>Acid-free glassine paper protection</li>
                  <li>Corner protectors and foam padding</li>
                  <li>Double-walled corrugated boxes</li>
                  <li>Moisture-resistant packaging when necessary</li>
                  <li>Fragile and directional handling labels</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="font-serif text-2xl font-light text-[#F5F5DC] mb-4">
                  Return Policy
                </h2>

                <h3 className="font-sans text-lg font-medium text-[#C9AB81] mb-3 mt-6">
                  Order Cancellation
                </h3>
                <p className="font-sans text-base text-[#F5F5DC] leading-relaxed mb-4">
                  Orders can be cancelled without any charges within 24 hours of purchase. After this period, cancellations are not accepted. Custom commissioned works are non-refundable unless defective.
                </p>

                <h3 className="font-sans text-lg font-medium text-[#C9AB81] mb-3 mt-6">
                  Returns
                </h3>
                <p className="font-sans text-base text-[#F5F5DC] leading-relaxed mb-4">
                  Returns are only accepted if the item arrives broken or significantly damaged during shipping.
                  If your artwork arrives damaged:
                </p>
                <ul className="font-sans text-base text-[#F5F5DC] leading-relaxed list-disc pl-6 space-y-2">
                  <li>Contact us immediately (within 24 hours of delivery) with photos of the damage and packaging.</li>
                  <li>Only broken or significantly damaged shipments will be eligible for a replacement, or a refund if a replacement is not possible.</li>
                  <li>Return shipping costs for damaged items covered by Art By Tarang.</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="font-serif text-2xl font-light text-[#F5F5DC] mb-4">
                  Processing Time
                </h2>
                <ul className="font-sans text-base text-[#F5F5DC] leading-relaxed list-disc pl-6 space-y-2">
                  <li>Orders processed within 1-3 business days</li>
                  <li>Custom framing adds 7-10 business days</li>
                  <li>Commission work timeline specified in agreement</li>
                  <li>You'll receive email confirmation when your order ships</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="font-serif text-2xl font-light text-[#F5F5DC] mb-4">
                  Insurance
                </h2>
                <p className="font-sans text-base text-[#F5F5DC] leading-relaxed mb-4">
                  All shipments are fully insured for the purchase price. In the unlikely event of loss or 
                  damage during transit, we will file the insurance claim and ensure you receive either a 
                  replacement or full refund.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="font-serif text-2xl font-light text-[#F5F5DC] mb-4">
                  Contact Us
                </h2>
                <p className="font-sans text-base text-[#F5F5DC] leading-relaxed mb-4">
                  For questions about shipping or returns:
                </p>
                <p className="font-sans text-base text-[#F5F5DC] leading-relaxed">
                  Email: artbytarang@gmail.com<br />
                  Response time: 24-48 hours
                </p>
              </section>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default ReturnsShipping;