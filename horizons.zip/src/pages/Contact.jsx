import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Mail, Instagram, Facebook, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const res = await fetch("https://api.web3forms.com/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          access_key: "f63c758a-4c7b-4f55-b178-26b7e3c7432e",
          from_name: "Inquiry_ArtByTarang",
          subject: formData.subject || "New Contact Form Message",
          name: formData.name,
          email: formData.email,
          message: formData.message,
        }),
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.message);

      toast({
        title: "Message Sent",
        description: "Thank you for reaching out! We'll respond to your inquiry within 24-48 hours.",
        variant: "default", // success
      });

      setFormData({ name: "", email: "", subject: "", message: "" });
    } catch (err) {
      toast({
        title: "Message not sent",
        description: err.message || "Please try again later.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = e => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <>
      <Helmet>
        <title>Contact - Art By Tarang</title>
        <meta name="description" content="Get in touch with Tarang Singh for inquiries about artwork, commissions, exhibitions, or general questions." />
      </Helmet>

      <div className="pt-20 bg-[#1E1E1E] text-[#F5F5DC] min-h-screen">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center mb-16">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <span className="font-sans text-sm uppercase tracking-wider text-[#C9AB81] mb-4 block">
                Get In Touch
              </span>
              <h1 className="font-serif text-5xl md:text-6xl font-light text-[#F5F5DC] mb-4">
                Contact
              </h1>
              <p className="font-sans text-lg text-[#F5F5DC]/80 max-w-2xl mx-auto">
                Have a question or interested in collaborating? I'd love to hear from you.
              </p>
            </motion.div>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <form onSubmit={handleSubmit} className="bg-[#2A2A2A] p-8 shadow-md space-y-6">
                <h2 className="font-serif text-2xl font-light text-[#F5F5DC] mb-6">
                  Send a Message
                </h2>

                <input
                  type="text"
                  name="name"
                  placeholder="Your Name *"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  disabled={isSubmitting}
                  className="w-full px-4 py-3 border border-gray-700 focus:border-[#C9AB81] focus:outline-none transition-colors font-sans text-sm bg-[#1E1E1E] text-[#F5F5DC] placeholder:text-gray-500 disabled:bg-gray-800"
                />

                <input
                  type="email"
                  name="email"
                  placeholder="Email Address *"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  disabled={isSubmitting}
                  className="w-full px-4 py-3 border border-gray-700 focus:border-[#C9AB81] focus:outline-none transition-colors font-sans text-sm bg-[#1E1E1E] text-[#F5F5DC] placeholder:text-gray-500 disabled:bg-gray-800"
                />

                <input
                  type="text"
                  name="subject"
                  placeholder="Subject *"
                  value={formData.subject}
                  onChange={handleChange}
                  required
                  disabled={isSubmitting}
                  className="w-full px-4 py-3 border border-gray-700 focus:border-[#C9AB81] focus:outline-none transition-colors font-sans text-sm bg-[#1E1E1E] text-[#F5F5DC] placeholder:text-gray-500 disabled:bg-gray-800"
                />

                <textarea
                  name="message"
                  placeholder="Your Message *"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows="6"
                  disabled={isSubmitting}
                  className="w-full px-4 py-3 border border-gray-700 focus:border-[#C9AB81] focus:outline-none transition-colors font-sans text-sm resize-none bg-[#1E1E1E] text-[#F5F5DC] placeholder:text-gray-500 disabled:bg-gray-800"
                />

                <Button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="w-full bg-[#C9AB81] hover:bg-[#B8956F] text-[#1A1A1A] font-sans uppercase tracking-wider py-6 text-base"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    'Send Message'
                  )}
                </Button>
              </form>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="space-y-8"
            >
              <div>
                <h2 className="font-serif text-2xl font-light text-[#F5F5DC] mb-6">
                  Connect
                </h2>

                <div className="space-y-6">
                  <div className="flex items-start">
                    <Mail className="w-6 h-6 text-[#C9AB81] mr-4 mt-1" />
                    <div>
                      <h3 className="font-sans text-sm uppercase tracking-wider text-gray-400 mb-1">
                        Email
                      </h3>
                      <a href="mailto:artbytarang@gmail.com" className="font-sans text-base text-[#F5F5DC] hover:text-[#C9AB81] transition-colors">artbytarang@gmail.com</a>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <Instagram className="w-6 h-6 text-[#C9AB81] mr-4 mt-1" />
                    <div>
                      <h3 className="font-sans text-sm uppercase tracking-wider text-gray-400 mb-1">
                        Instagram
                      </h3>
                      <a href="https://www.instagram.com/artistic_tarang1?igsh=MWJpM2QwMTQxNXltOQ%3D%3D&utm_source=qr" target="_blank" rel="noopener noreferrer" className="font-sans text-base text-[#F5F5DC] hover:text-[#C9AB81] transition-colors">@artistic_tarang1</a>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <Facebook className="w-6 h-6 text-[#C9AB81] mr-4 mt-1" />
                    <div>
                      <h3 className="font-sans text-sm uppercase tracking-wider text-gray-400 mb-1">
                        Facebook
                      </h3>
                      <a href="https://www.facebook.com/share/17mm4ouRYX/?mibextid=wwXIfr" target="_blank" rel="noopener noreferrer" className="font-sans text-base text-[#F5F5DC] hover:text-[#C9AB81] transition-colors">
                        Art By Tarang
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-[#2A2A2A] p-8">
                <h3 className="font-serif text-xl font-light text-[#F5F5DC] mb-4">
                  Inquiries
                </h3>
                <ul className="space-y-3 font-sans text-sm text-[#F5F5DC]/80">
                  <li>• General artwork inquiries</li>
                  <li>• Commission proposals</li>
                  <li>• Exhibition opportunities</li>
                  <li>• Gallery partnerships</li>
                </ul>
              </div>

              <div className="bg-[#2A2A2A] p-8 shadow-md">
                <h3 className="font-serif text-xl font-light text-[#F5F5DC] mb-4">
                  Response Time
                </h3>
                <p className="font-sans text-sm text-[#F5F5DC]/80 leading-relaxed">
                  I typically respond to all inquiries within 24-48 hours. For urgent matters 
                  regarding available artwork or time-sensitive commissions, please mention 
                  this in your message.
                </p>
              </div >
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Contact;