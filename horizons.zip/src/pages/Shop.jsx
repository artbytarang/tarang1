import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Loader2, Search, ShoppingBag, X } from 'lucide-react';
import { getProducts, getProductQuantities, formatCurrency } from '@/api/EcommerceApi';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const VALID_DISCOUNT_CODES = {
  'WELCOME20': 0.20,
  'ART10': 0.10,
  'SAVE5': 0.05
};

const Shop = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [discountCode, setDiscountCode] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true);
        // 1. Fetch base products
        const data = await getProducts();
        let productList = data.products || [];

        // 2. Fetch real-time inventory to filter out sold items
        if (productList.length > 0) {
          const productIds = productList.map(p => p.id);
          const quantities = await getProductQuantities({ fields: 'inventory_quantity', product_ids: productIds });
          
          const quantityMap = new Map();
          if (quantities && quantities.variants) {
             quantities.variants.forEach(v => quantityMap.set(v.id, v.inventory_quantity));
          }

          productList = productList.map(p => ({
              ...p,
              variants: p.variants.map(v => ({
                  ...v,
                  inventory_quantity: quantityMap.get(v.id) ?? v.inventory_quantity
              }))
          }));
        }

        setProducts(productList);
      } catch (error) {
        console.error("Failed to fetch products:", error);
        toast({
          title: "Error",
          description: "Failed to load products. Please try again later.",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, [toast]);

  const handleApplyDiscount = () => {
    const code = discountCode.trim().toUpperCase();
    if (VALID_DISCOUNT_CODES[code]) {
      setAppliedDiscount({ code, percent: VALID_DISCOUNT_CODES[code] });
      toast({
        title: "Discount Applied!",
        description: `${code} successfully applied. Prices updated.`,
      });
    } else {
      toast({
        title: "Invalid Code",
        description: "The discount code provided is not valid.",
        variant: "destructive",
      });
    }
  };

  const clearDiscount = () => {
    setAppliedDiscount(null);
    setDiscountCode('');
    toast({
      description: "Discount removed.",
    });
  };

  // Filter products: Must match search AND be available (in stock)
  const filteredProducts = products.filter(product => {
    const matchesSearch = product.title.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Check Availability
    // 1. Must be purchasable (active)
    if (!product.purchasable) return false;

    // 2. Must have at least one variant in stock
    // (A variant is in stock if manage_inventory is false OR inventory_quantity > 0)
    const hasStock = product.variants.some(v => 
      !v.manage_inventory || (v.inventory_quantity !== null && v.inventory_quantity > 0)
    );

    return matchesSearch && hasStock;
  });

  const calculatePrice = (product) => {
    // Assuming the first variant is the main price for the grid display
    const variant = product.variants?.[0];
    if (!variant) return null;

    const basePrice = variant.price_in_cents;
    const currency = variant.currency_info;
    
    let finalPrice = basePrice;
    let isDiscounted = false;

    if (appliedDiscount) {
      finalPrice = Math.round(basePrice * (1 - appliedDiscount.percent));
      isDiscounted = true;
    }

    return {
      baseFormatted: formatCurrency(basePrice, currency),
      finalFormatted: formatCurrency(finalPrice, currency),
      isDiscounted
    };
  };

  return (
    <div className="min-h-screen bg-[#1E1E1E] pt-24 pb-16 text-[#F5F5DC]">
      <Helmet>
        <title>Shop All | Art By Tarang</title>
        <meta name="description" content="Browse available fine art prints and originals." />
      </Helmet>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <h1 className="font-serif text-4xl md:text-5xl text-[#F5F5DC] mb-4">Shop Collection</h1>
            <p className="text-[#F5F5DC]/80 font-sans max-w-lg">
              Explore our selection of available artwork. 
              Find the perfect piece to elevate your space today.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto items-start sm:items-end">
             {/* Discount Input */}
             <div className="relative w-full sm:w-64">
                {appliedDiscount ? (
                  <div className="flex items-center justify-between p-2 border border-[#C9AB81] bg-[#C9AB81]/20 rounded-md">
                    <span className="text-sm font-medium text-[#F5F5DC] pl-2">
                      Code: {appliedDiscount.code} (-{appliedDiscount.percent * 100}%)
                    </span>
                    <Button variant="ghost" size="sm" onClick={clearDiscount} className="h-8 w-8 p-0 hover:bg-transparent text-[#F5F5DC] hover:text-red-400">
                      <X size={16} />
                    </Button>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <Input 
                      placeholder="Promo Code" 
                      value={discountCode}
                      onChange={(e) => setDiscountCode(e.target.value)}
                      className="bg-[#2A2A2A] text-[#F5F5DC] border-gray-700 placeholder:text-gray-500 focus:border-[#C9AB81]"
                    />
                    <Button onClick={handleApplyDiscount} variant="outline" className="shrink-0 border-[#C9AB81] text-[#C9AB81] hover:bg-[#C9AB81] hover:text-[#1A1A1A]">
                      Apply
                    </Button>
                  </div>
                )}
             </div>

             {/* Search */}
             <div className="relative w-full sm:w-64">
               <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
               <Input 
                 placeholder="Search available works..." 
                 value={searchQuery}
                 onChange={(e) => setSearchQuery(e.target.value)}
                 className="pl-10 bg-[#2A2A2A] text-[#F5F5DC] border-gray-700 placeholder:text-gray-500 focus:border-[#C9AB81]"
               />
             </div>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-20">
            <Loader2 className="h-12 w-12 text-[#C9AB81] animate-spin" />
          </div>
        ) : filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            <AnimatePresence>
              {filteredProducts.map((product) => {
                 const priceInfo = calculatePrice(product);
                 return (
                  <motion.div
                    key={product.id}
                    layout
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="group"
                  >
                    <Link to={`/product/${product.id}`} className="block">
                      <div className="relative aspect-[4/5] overflow-hidden bg-gray-800 mb-4 shadow-lg">
                        <img 
                          src={product.image || "https://images.unsplash.com/photo-1579783902614-a3fb39279c0b?q=80&w=1000&auto=format&fit=crop"} 
                          alt={product.title}
                          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                        />
                        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
                        
                        {priceInfo?.isDiscounted && (
                          <div className="absolute top-4 right-4 bg-[#C9AB81] text-[#1A1A1A] text-xs font-bold px-3 py-1 rounded-full shadow-sm">
                            -{appliedDiscount.percent * 100}% OFF
                          </div>
                        )}
                        
                        {/* Status Badge (Since we only show active, maybe just 'Active' or 'Sale') */}
                         <div className="absolute top-4 left-4 z-10">
                          <span className="font-sans text-xs uppercase tracking-wider text-[#1A1A1A] bg-[#F5F5DC] px-3 py-1 font-medium shadow-sm">
                            Available
                          </span>
                        </div>
                      </div>
                      
                      <h3 className="font-serif text-lg text-[#F5F5DC] group-hover:text-[#C9AB81] transition-colors truncate">
                        {product.title}
                      </h3>
                      
                      <div className="flex items-center gap-2 mt-1">
                        {priceInfo ? (
                          <>
                             <span className={`font-medium ${priceInfo.isDiscounted ? 'text-red-400' : 'text-[#F5F5DC]'}`}>
                               {priceInfo.finalFormatted}
                             </span>
                             {priceInfo.isDiscounted && (
                               <span className="text-sm text-gray-500 line-through">
                                 {priceInfo.baseFormatted}
                               </span>
                             )}
                          </>
                        ) : (
                          <span className="text-gray-500">Price Unavailable</span>
                        )}
                      </div>
                    </Link>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        ) : (
          <div className="text-center py-20">
            <ShoppingBag className="mx-auto h-12 w-12 text-gray-700 mb-4" />
            <h3 className="text-lg font-medium text-[#F5F5DC]">No available products found</h3>
            <p className="text-gray-500">Try adjusting your search terms or check back later.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Shop;