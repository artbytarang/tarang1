import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import ProductsList from '@/components/ProductsList';
import { getProducts } from '@/api/EcommerceApi';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Palette, ArrowRight, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const Home = () => {
  const [featuredProducts, setFeaturedProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Newsletter state
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await getProducts({ limit: 3 });
        if (response && response.data) {
          setFeaturedProducts(response.data);
        }
      } catch (error) {
        console.error('Failed to fetch products:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  const handleSubscribe = async (e) => {
    e.preventDefault();
    
    if (!email) {
      toast({
        title: "Email Required",
        description: "Please enter your email address to subscribe.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const res = await fetch("https://api.web3forms.com/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          access_key: "f63c758a-4c7b-4f55-b178-26b7e3c7432e", // Web3Forms Access Key
          from_name: "Art By Tarang Website",
          subject: "New Newsletter Subscriber",
          email: email,
          message: `New subscriber added to collector's list: ${email}`
        }),
      });
      
      const data = await res.json();
      if (!data.success) throw new Error(data.message);

      toast({
        title: "Subscribed Successfully",
        description: "Welcome to the Collector's List! You'll be the first to know about new releases.",
        variant: "default"
      });
      
      setEmail('');
    } catch (error) {
      toast({
        title: "Subscription Failed",
        description: error.message || "Please try again later.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Art By Tarang | Original Contemporary Abstract & Mixed Media Art</title>
        <meta name="description" content="Welcome to Art By Tarang. Discover unique original contemporary paintings, abstract art, and mixed-media masterpieces by artist Tarang Singh. Shop fine art and prints online." />
        <meta name="keywords" content="Art By Tarang, Tarang Singh, original art, contemporary art, abstract painting, mixed media art, buy art online, fine art prints, modern art gallery, wall art" />
      </Helmet>
      
      <main>
        {/* Hero Section */}
        <section className="relative h-[90vh] flex items-center justify-center overflow-hidden bg-[#1A1A1A]">
          <div className="absolute inset-0 z-0">
             <div className="absolute inset-0 bg-black/40 z-10" />
             <img 
               src="https://images.unsplash.com/photo-1547891654-e66ed7ebb968?q=80&w=2070&auto=format&fit=crop"
               alt="Abstract artistic texture background" 
               className="w-full h-full object-cover opacity-80"
              />
          </div>
          
          <div className="relative z-20 text-center px-4 max-w-4xl mx-auto">
            <motion.span 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-block font-sans text-sm md:text-base uppercase tracking-[0.2em] text-[#F5F5DC] mb-6"
            >
              Original Contemporary Art
            </motion.span>
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="font-serif text-5xl md:text-7xl lg:text-8xl font-light text-white mb-8 leading-tight"
            >
              Art that breathes<br/>life into space
            </motion.h1>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Link to="/gallery">
                <Button className="bg-[#C9AB81] hover:bg-[#b89a70] text-[#1A1A1A] font-sans uppercase tracking-wider px-10 py-7 rounded-none text-base min-w-[200px]">
                  View Gallery
                </Button>
              </Link>
              <Link to="/the-artist">
                <Button variant="outline" className="border-white text-white hover:bg-white hover:text-[#1A1A1A] font-sans uppercase tracking-wider px-10 py-7 rounded-none text-base min-w-[200px] bg-transparent">
                  Meet the Artist
                </Button>
              </Link>
            </motion.div>
          </div>
        </section>
        
        {/* Featured Works Section */}
        <section className="py-24 bg-[#FFFEF9]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <span className="font-sans text-sm uppercase tracking-wider text-[#C9AB81] mb-4 block">
                Selected Works
              </span>
              <h2 className="font-serif text-4xl md:text-5xl font-light text-[#1A1A1A]">
                Featured Collection
              </h2>
            </div>
            
            <ProductsList products={featuredProducts} loading={loading} />
            
            <div className="mt-16 text-center">
              <Link to="/gallery">
                <Button variant="outline" className="group border-[#1A1A1A] text-[#1A1A1A] hover:bg-[#1A1A1A] hover:text-[#F5F5DC] font-sans uppercase tracking-wider px-12 py-6 rounded-none transition-all duration-300">
                  View Full Gallery
                  <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Commission Section */}
        <section className="py-24 bg-[#1A1A1A] relative overflow-hidden">
          {/* Background decoration */}
          <div className="absolute top-0 right-0 w-1/3 h-full bg-[#1e1e1e] transform skew-x-12 translate-x-20 opacity-50 pointer-events-none"></div>
          
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
              >
                <div className="flex items-center gap-4 mb-6">
                  <div className="p-3 bg-[#C9AB81]/10 rounded-full">
                    <Palette className="w-6 h-6 text-[#C9AB81]" />
                  </div>
                  <span className="font-sans text-sm uppercase tracking-wider text-[#C9AB81]">
                    Bespoke Art Services
                  </span>
                </div>
                
                <h2 className="font-serif text-4xl md:text-5xl font-light text-[#F5F5DC] mb-6 leading-tight">
                  Interested in commissioning a custom artwork?
                </h2>
                
                <div className="space-y-6 text-[#F5F5DC]/80 font-sans text-lg leading-relaxed">
                  <p>
                    Collaborate directly with Tarang to create a unique masterpiece that perfectly complements your space.
                  </p>
                  <p>
                    Share your ideas, preferred size, color palette, and timeline. Whether you're looking for a specific mood or a statement piece for a particular wall, we'll work together to bring your vision to life.
                  </p>
                </div>

                <div className="mt-10 flex flex-col sm:flex-row gap-4">
                  <Link to="/commissions">
                    <Button className="bg-[#C9AB81] hover:bg-[#b89a70] text-[#1A1A1A] font-sans uppercase tracking-wider px-6 py-5 rounded-none text-sm md:text-base w-full sm:w-auto">
                      Start Your Project
                    </Button>
                  </Link>
                  <Link to="/contact">
                    <Button variant="outline" className="border-[#F5F5DC] text-[#F5F5DC] hover:bg-[#F5F5DC] hover:text-[#1A1A1A] font-sans uppercase tracking-wider px-6 py-5 rounded-none text-sm md:text-base bg-transparent w-full sm:w-auto">
                      Contact for Details
                    </Button>
                  </Link>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="relative h-[500px] w-full"
              >
                <div className="absolute inset-0 bg-[#C9AB81] transform rotate-3 rounded-sm opacity-20"></div>
                <img 
                  alt="Luxurious high-end minimalist art studio interior with large windows and no people"
                  className="relative w-full h-full object-cover shadow-2xl grayscale hover:grayscale-0 transition-all duration-700"
                 src="https://images.unsplash.com/photo-1640622299541-8c8ab8a098f3" />
              </motion.div>
            </div>
          </div>
        </section>

        {/* Newsletter / Bottom CTA Section */}
        <section className="py-20 bg-[#F5F5DC]">
           <div className="max-w-4xl mx-auto px-4 text-center">
              <h2 className="font-serif text-3xl md:text-4xl text-[#1A1A1A] mb-4">Join the Collector's List</h2>
              <p className="font-sans text-gray-600 mb-8 max-w-xl mx-auto">
                Be the first to know about new collection releases, upcoming exhibitions, and exclusive studio updates.
              </p>
              <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
                <input 
                  type="email" 
                  placeholder="Your email address" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="flex-1 bg-white border border-gray-300 px-4 py-3 font-sans focus:outline-none focus:border-[#C9AB81]"
                  required
                  disabled={isSubmitting}
                />
                <Button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="bg-[#1A1A1A] text-white hover:bg-[#333] font-sans uppercase tracking-wider px-8 py-3 rounded-none"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Wait
                    </>
                  ) : 'Subscribe'}
                </Button>
              </form>
           </div>
        </section>
      </main>
    </>
  );
};

export default Home;