import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';

const TermsConditions = () => {
  useEffect(() => {
    // Scroll to the top of the page when the component mounts
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <Helmet>
        <title>Terms & Conditions - Art By Tarang</title>
        <meta name="description" content="Terms and Conditions for purchasing artwork from Art By Tarang. Read our policies and guidelines." />
      </Helmet>

      <div className="pt-20 bg-[#1E1E1E] min-h-screen text-[#F5F5DC]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="font-serif text-5xl md:text-6xl font-light text-[#F5F5DC] mb-8">
              Terms & Conditions
            </h1>

            <div className="prose prose-lg max-w-none">
              <p className="font-sans text-sm text-gray-400 mb-8">
                Last Updated: December 27, 2025
              </p>

              <section className="mb-8">
                <h2 className="font-serif text-2xl font-light text-[#F5F5DC] mb-4">
                  Acceptance of Terms
                </h2>
                <p className="font-sans text-base text-[#F5F5DC] leading-relaxed mb-4">
                  By accessing and using this website, you accept and agree to be bound by these Terms and Conditions. 
                  If you do not agree with any part of these terms, please do not use our website or services.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="font-serif text-2xl font-light text-[#F5F5DC] mb-4">
                  Artwork Sales
                </h2>
                <p className="font-sans text-base text-[#F5F5DC] leading-relaxed mb-4">
                  All artwork listed on this website is original, one-of-a-kind unless otherwise stated. Prices are 
                  in USD and subject to change without notice. Once an artwork is sold, it is marked as unavailable.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="font-serif text-2xl font-light text-[#F5F5DC] mb-4">
                  Orders and Payment
                </h2>
                <ul className="font-sans text-base text-[#F5F5DC] leading-relaxed list-disc pl-6 space-y-2">
                  <li>All orders are subject to acceptance and availability</li>
                  <li>Payment must be received in full before shipping</li>
                  <li>We accept major credit cards and secure payment methods</li>
                  <li>Prices do not include shipping or applicable taxes</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="font-serif text-2xl font-light text-[#F5F5DC] mb-4">
                  Intellectual Property
                </h2>
                <p className="font-sans text-base text-[#F5F5DC] leading-relaxed mb-4">
                  All artwork, photographs, text, graphics, and other content on this website are the intellectual 
                  property of Tarang Singh and protected by copyright law. Purchasing artwork transfers physical 
                  ownership but does not transfer reproduction rights unless explicitly stated.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="font-serif text-2xl font-light text-[#F5F5DC] mb-4">
                  Commission Agreements
                </h2>
                <p className="font-sans text-base text-[#F5F5DC] leading-relaxed mb-4">
                  Custom commissions require a separate written agreement. A non-refundable deposit (typically 50%) 
                  is required to begin work. Final payment is due before delivery.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="font-serif text-2xl font-light text-[#F5F5DC] mb-4">
                  Limitation of Liability
                </h2>
                <p className="font-sans text-base text-[#F5F5DC] leading-relaxed mb-4">
                  Art By Tarang shall not be liable for any indirect, incidental, or consequential damages arising 
                  from the use of this website or purchase of artwork.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="font-serif text-2xl font-light text-[#F5F5DC] mb-4">
                  Governing Law
                </h2>
                <p className="font-sans text-base text-[#F5F5DC] leading-relaxed mb-4">
                  These Terms and Conditions are governed by and construed in accordance with applicable laws. 
                  Any disputes shall be resolved through binding arbitration.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="font-serif text-2xl font-light text-[#F5F5DC] mb-4">
                  Contact
                </h2>
                <p className="font-sans text-base text-[#F5F5DC] leading-relaxed mb-4">
                  For questions regarding these Terms and Conditions, please contact:
                </p>
                <p className="font-sans text-base text-[#F5F5DC] leading-relaxed">
                  Email: legal@artbytarang.com
                </p>
              </section>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default TermsConditions;