import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { CheckCircle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const Commissions = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    projectType: '',
    dimensions: '',
    budget: '',
    description: '',
    timeline: ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const res = await fetch("https://api.web3forms.com/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          access_key: "f63c758a-4c7b-4f55-b178-26b7e3c7432e",
          from_name: "Art By Tarang Commissions",
          subject: `New Commission Inquiry: ${formData.projectType || 'General'} from ${formData.name}`,
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          projectType: formData.projectType,
          dimensions: formData.dimensions,
          budget: formData.budget,
          description: formData.description,
          timeline: formData.timeline,
          replyto: formData.email,
        }),
      });

      const data = await res.json();
      if (!data.success) throw new Error(data.message);

      toast({
        title: "Commission Inquiry Sent",
        description: "Thank you for your interest! I’ll get back to you within 24–48 hours.",
      });

      setFormData({
        name: '',
        email: '',
        phone: '',
        projectType: '',
        dimensions: '',
        budget: '',
        description: '',
        timeline: ''
      });
    } catch (error) {
      toast({
        title: "Submission Failed",
        description: error.message || "There was an error sending your message.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <>
      <Helmet>
        <title>Commission Custom Artwork | Art By Tarang</title>
        <meta name="description" content="Commission a bespoke artwork by Tarang Singh." />
      </Helmet>

      <div className="pt-20 bg-[#1E1E1E] text-[#F5F5DC] min-h-screen">
        <section className="py-20">
          <div className="max-w-4xl mx-auto px-4">
            <motion.form
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              onSubmit={handleSubmit}
              className="bg-[#2A2A2A] p-8 shadow-md space-y-6"
            >
              <h2 className="font-serif text-4xl font-light text-center text-[#F5F5DC]">
                Commission Inquiry
              </h2>

              <div className="grid md:grid-cols-2 gap-6">
                <input
                  type="text"
                  name="name"
                  placeholder="Full Name *"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="px-4 py-3 border border-gray-700 focus:border-[#C9AB81] focus:outline-none font-sans text-sm bg-[#1E1E1E] text-[#F5F5DC] placeholder:text-gray-500 disabled:bg-gray-800"
                  disabled={isSubmitting}
                />
                <input
                  type="email"
                  name="email"
                  placeholder="Email Address *"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="px-4 py-3 border border-gray-700 focus:border-[#C9AB81] focus:outline-none font-sans text-sm bg-[#1E1E1E] text-[#F5F5DC] placeholder:text-gray-500 disabled:bg-gray-800"
                  disabled={isSubmitting}
                />
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <input
                  type="tel"
                  name="phone"
                  placeholder="Phone Number"
                  value={formData.phone}
                  onChange={handleChange}
                  className="px-4 py-3 border border-gray-700 focus:border-[#C9AB81] focus:outline-none font-sans text-sm bg-[#1E1E1E] text-[#F5F5DC] placeholder:text-gray-500 disabled:bg-gray-800"
                  disabled={isSubmitting}
                />
                <select
                  name="projectType"
                  value={formData.projectType}
                  onChange={handleChange}
                  required
                  className="px-4 py-3 border border-gray-700 focus:border-[#C9AB81] focus:outline-none font-sans text-sm bg-[#1E1E1E] text-[#F5F5DC] placeholder:text-gray-500 disabled:bg-gray-800"
                  disabled={isSubmitting}
                >
                  <option value="">Project Type *</option>
                  <option value="single">Single Artwork</option>
                  <option value="series">Series of Works</option>
                  <option value="mural">Mural</option>
                  <option value="other">Other</option>
                </select>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <input
                  type="text"
                  name="dimensions"
                  placeholder="Desired Dimensions"
                  value={formData.dimensions}
                  onChange={handleChange}
                  className="px-4 py-3 border border-gray-700 focus:border-[#C9AB81] focus:outline-none font-sans text-sm bg-[#1E1E1E] text-[#F5F5DC] placeholder:text-gray-500 disabled:bg-gray-800"
                  disabled={isSubmitting}
                />

                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-sans text-sm">
                    $
                  </span>
                  <input
                    type="text"
                    name="budget"
                    placeholder="Desired Budget"
                    value={formData.budget}
                    onChange={handleChange}
                    className="w-full pl-8 pr-4 py-3 border border-gray-700 focus:border-[#C9AB81] focus:outline-none font-sans text-sm bg-[#1E1E1E] text-[#F5F5DC] placeholder:text-gray-500 disabled:bg-gray-800"
                    disabled={isSubmitting}
                  />
                </div>
              </div>

              <input
                type="text"
                name="timeline"
                placeholder="Desired Timeline"
                value={formData.timeline}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-700 focus:border-[#C9AB81] focus:outline-none font-sans text-sm bg-[#1E1E1E] text-[#F5F5DC] placeholder:text-gray-500 disabled:bg-gray-800"
                disabled={isSubmitting}
              />

              <textarea
                name="description"
                placeholder="Project Description *"
                value={formData.description}
                onChange={handleChange}
                required
                rows="6"
                className="w-full px-4 py-3 border border-gray-700 focus:border-[#C9AB81] focus:outline-none font-sans text-sm resize-none bg-[#1E1E1E] text-[#F5F5DC] placeholder:text-gray-500 disabled:bg-gray-800"
                disabled={isSubmitting}
              />

              <Button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-[#C9AB81] hover:bg-[#B8956F] text-[#1A1A1A] uppercase tracking-wider py-6"
              >
                {isSubmitting ? (
                  <span className="flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin" /> Sending Inquiry...
                  </span>
                ) : (
                  "Submit Inquiry"
                )}
              </Button>

              <p className="text-xs text-gray-400 text-center">
                Typical response time: 24–48 hours
              </p>
            </motion.form>
          </div>
        </section>
      </div>
    </>
  );
};

export default Commissions;