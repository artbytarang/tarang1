import React, { useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingCart as ShoppingCartIcon, X, Plus, Minus, Trash2 } from 'lucide-react';
import { useCart } from '@/hooks/useCart';
import { Button } from '@/components/ui/button';
import { initializeCheckout } from '@/api/EcommerceApi';
import { useToast } from '@/components/ui/use-toast';

const ShoppingCart = () => {
  const { toast } = useToast();
  const { cartItems, removeFromCart, updateQuantity, getCartTotal, clearCart, isCartOpen, setIsCartOpen } = useCart();

  const handleCheckout = useCallback(async () => {
    if (cartItems.length === 0) {
      toast({
        title: 'Your cart is empty',
        description: 'Add some products to your cart before checking out.',
        variant: 'destructive',
      });
      return;
    }

    try {
      const items = cartItems.map(item => ({
        variant_id: item.variant.id,
        quantity: item.quantity,
      }));

      const successUrl = `${window.location.origin}/success`;
      const cancelUrl = window.location.href;

      const { url } = await initializeCheckout({ items, successUrl, cancelUrl });

      clearCart();
      window.location.href = url;
    } catch (error) {
      toast({
        title: 'Checkout Error',
        description: 'There was a problem initializing checkout. Please try again.',
        variant: 'destructive',
      });
    }
  }, [cartItems, clearCart, toast]);

  return (
    <AnimatePresence>
      {isCartOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/60 z-[100]"
          onClick={() => setIsCartOpen(false)}
        >
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="absolute right-0 top-0 h-full w-full max-w-md bg-[#1A1A1A] border-l border-[#C9AB81]/20 shadow-2xl flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-6 border-b border-[#C9AB81]/20">
              <h2 className="font-serif text-2xl font-light text-[#F5F5DC]">Shopping Cart</h2>
              <Button onClick={() => setIsCartOpen(false)} variant="ghost" size="icon" className="text-[#F5F5DC] hover:bg-white/10 hover:text-[#C9AB81]">
                <X className="w-6 h-6" />
              </Button>
            </div>
            
            <div className="flex-grow p-6 overflow-y-auto space-y-6">
              {cartItems.length === 0 ? (
                <div className="text-center text-[#F5F5DC]/50 h-full flex flex-col items-center justify-center">
                  <ShoppingCartIcon size={48} className="mb-4 opacity-50" />
                  <p className="font-sans text-lg">Your cart is empty.</p>
                  <Button 
                    onClick={() => setIsCartOpen(false)}
                    variant="link" 
                    className="text-[#C9AB81] mt-4"
                  >
                    Start Shopping
                  </Button>
                </div>
              ) : (
                cartItems.map(item => (
                  <div key={item.variant.id} className="flex gap-4 bg-[#2A2A2A] p-4 rounded-lg border border-[#C9AB81]/10">
                    <img src={item.product.image} alt={item.product.title} className="w-20 h-24 object-cover rounded-sm" />
                    <div className="flex-grow flex flex-col justify-between">
                      <div>
                        <h3 className="font-serif text-lg font-light text-[#F5F5DC] leading-tight mb-1">{item.product.title}</h3>
                        <p className="font-sans text-xs text-[#F5F5DC]/60 mb-2">{item.variant.title !== 'Default Title' ? item.variant.title : ''}</p>
                      </div>
                      
                      <div className="flex items-center justify-between">
                         <div className="flex items-center border border-[#C9AB81]/30 rounded-md">
                          <button 
                            onClick={() => updateQuantity(item.variant.id, Math.max(1, item.quantity - 1))}
                            className="px-2 py-1 text-[#F5F5DC] hover:text-[#C9AB81] transition-colors"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="px-2 font-sans text-xs text-[#F5F5DC]">{item.quantity}</span>
                          <button 
                            onClick={() => updateQuantity(item.variant.id, item.quantity + 1)}
                            className="px-2 py-1 text-[#F5F5DC] hover:text-[#C9AB81] transition-colors"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                        <p className="font-sans text-sm text-[#C9AB81] font-medium">
                          {item.variant.sale_price_formatted || item.variant.price_formatted}
                        </p>
                      </div>
                    </div>
                    <button 
                      onClick={() => removeFromCart(item.variant.id)}
                      className="text-[#F5F5DC]/40 hover:text-red-400 transition-colors self-start"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))
              )}
            </div>

            {cartItems.length > 0 && (
              <div className="p-6 border-t border-[#C9AB81]/20 bg-[#2A2A2A]">
                <div className="flex justify-between items-center mb-6">
                  <span className="font-serif text-xl font-light text-[#F5F5DC]">Total</span>
                  <span className="font-sans text-xl font-medium text-[#C9AB81]">{getCartTotal()}</span>
                </div>
                <Button 
                  onClick={handleCheckout} 
                  className="w-full bg-[#C9AB81] hover:bg-[#B8956F] text-[#1A1A1A] font-sans uppercase tracking-wider py-6 text-sm font-medium transition-colors"
                >
                  Proceed to Checkout
                </Button>
                <p className="text-center text-[#F5F5DC]/40 text-xs mt-4 font-sans">
                  Shipping & taxes calculated at checkout
                </p>
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default ShoppingCart;