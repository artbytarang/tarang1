import React from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Facebook } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-[#1A1A1A] text-[#F5F5DC] py-12 border-t border-[#C9AB81]/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          <div>
            <span className="font-serif text-2xl font-light text-[#C9AB81] tracking-wide block mb-4">
              Art By Tarang
            </span>
            <p className="font-sans text-sm text-[#F5F5DC]/70 leading-relaxed">
              Explore the unique artistic vision of Tarang Singh through contemporary mixed-media artwork.
            </p>
          </div>

          <div>
            <span className="font-sans text-sm uppercase tracking-wider text-[#C9AB81] block mb-4">
              Quick Links
            </span>
            <div className="space-y-2">
              <Link to="/about" className="block font-sans text-sm text-[#F5F5DC]/70 hover:text-[#C9AB81] transition-colors">
                About the Artist
              </Link>
              <Link to="/gallery" className="block font-sans text-sm text-[#F5F5DC]/70 hover:text-[#C9AB81] transition-colors">
                Gallery
              </Link>
              <Link to="/contact" className="block font-sans text-sm text-[#F5F5DC]/70 hover:text-[#C9AB81] transition-colors">
                Contact
              </Link>
            </div>
          </div>

          <div>
            <span className="font-sans text-sm uppercase tracking-wider text-[#C9AB81] block mb-4">
              Connect
            </span>
            <div className="flex space-x-4 mb-4">
              <a
                href="https://www.instagram.com/artistic_tarang1?igsh=MWJpM2QwMTQxNXltOQ%3D%3D&utm_source=qr"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#F5F5DC]/70 hover:text-[#C9AB81] transition-colors"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="https://www.facebook.com/share/17mm4ouRYX/?mibextid=wwXIfr"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#F5F5DC]/70 hover:text-[#C9AB81] transition-colors"
              >
                <Facebook className="w-5 h-5" />
              </a>
            </div>
            <div className="space-y-2">
              <Link to="/privacy-policy" className="block font-sans text-sm text-[#F5F5DC]/70 hover:text-[#C9AB81] transition-colors">
                Privacy Policy
              </Link>
              <Link to="/terms-conditions" className="block font-sans text-sm text-[#F5F5DC]/70 hover:text-[#C9AB81] transition-colors">
                Terms & Conditions
              </Link>
              <Link to="/returns-shipping" className="block font-sans text-sm text-[#F5F5DC]/70 hover:text-[#C9AB81] transition-colors">
                Returns & Shipping
              </Link>
            </div>
          </div>
        </div>

        <div className="border-t border-[#C9AB81]/20 pt-8 text-center">
          <p className="font-sans text-sm text-[#F5F5DC]/70">
            © {new Date().getFullYear()} Art By Tarang. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;