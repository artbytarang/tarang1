import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, ShoppingCart, User } from 'lucide-react';
import { useCart } from '@/hooks/useCart';

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const { toggleCart, totalItems } = useCart();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  const navLinks = [
    { title: 'Home', path: '/' },
    { title: 'The Artist', path: '/the-artist' },
    { title: 'Gallery', path: '/gallery' },
    { title: 'Shop', path: '/shop' },
    { title: 'Commissions', path: '/commissions' },
    { title: 'Contact', path: '/contact' },
  ];

  const headerClass = `fixed w-full z-50 transition-all duration-300 ${
    scrolled || isOpen ? 'bg-[#1E1E1E]/95 backdrop-blur-sm border-b border-[#C9AB81]/20 py-4' : 'bg-transparent py-6'
  }`;

  return (
    <header className={headerClass}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <Link to="/" className="z-50 group">
            <span className="font-serif text-2xl font-semibold tracking-wide text-[#F5F5DC] group-hover:text-[#C9AB81] transition-colors">
              ART BY TARANG
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`text-sm font-medium tracking-wide transition-colors hover:text-[#C9AB81] ${
                  location.pathname === link.path ? 'text-[#C9AB81]' : 'text-[#F5F5DC]'
                }`}
              >
                {link.title.toUpperCase()}
              </Link>
            ))}
          </nav>

          {/* Right Actions */}
          <div className="hidden md:flex items-center space-x-6">
            <button 
              onClick={toggleCart}
              className="relative p-2 text-[#F5F5DC] hover:text-[#C9AB81] transition-colors"
              aria-label="Shopping Cart"
            >
              <ShoppingCart className="h-5 w-5" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#C9AB81] text-[#1A1A1A] text-[10px] font-bold h-4 w-4 rounded-full flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center gap-4 md:hidden">
             <button 
                onClick={toggleCart}
                className="relative p-2 text-[#F5F5DC]"
                aria-label="Shopping Cart"
              >
                <ShoppingCart className="h-5 w-5" />
                {totalItems > 0 && (
                  <span className="absolute -top-1 -right-1 bg-[#C9AB81] text-[#1A1A1A] text-[10px] font-bold h-4 w-4 rounded-full flex items-center justify-center">
                    {totalItems}
                  </span>
                )}
            </button>
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 text-[#F5F5DC] hover:text-[#C9AB81] transition-colors z-50"
              aria-label="Toggle Menu"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-0 w-full bg-[#1E1E1E] border-b border-[#C9AB81]/20 shadow-lg md:hidden"
          >
            <nav className="flex flex-col py-8 px-4 space-y-6 text-center">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`text-lg font-serif tracking-wide transition-colors ${
                    location.pathname === link.path ? 'text-[#C9AB81]' : 'text-[#F5F5DC]'
                  }`}
                  onClick={() => setIsOpen(false)}
                >
                  {link.title}
                </Link>
              ))}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Navigation;