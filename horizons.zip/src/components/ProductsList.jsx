import React, { useMemo, useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Loader2, Search } from 'lucide-react';
import { getProducts, getProductQuantities, formatCurrency } from '@/api/EcommerceApi';

const placeholderImage = "https://images.unsplash.com/photo-1579783902614-a3fb39279c0b?q=80&w=1000&auto=format&fit=crop";

const ProductCard = ({ product, index }) => {
  const displayVariant = useMemo(() => product.variants[0], [product]);
  
  // Price Logic
  const priceDisplay = useMemo(() => {
    if (!product.variants || product.variants.length === 0) return null;

    // Check if we have multiple variants with potentially different prices
    if (product.variants.length > 1) {
      // Find lowest price
      const prices = product.variants.map(v => v.sale_price_in_cents ?? v.price_in_cents);
      const minPrice = Math.min(...prices);
      const minPriceVariant = product.variants.find(v => (v.sale_price_in_cents ?? v.price_in_cents) === minPrice);
      
      const formatted = formatCurrency(minPrice, minPriceVariant?.currency_info);
      return { type: 'range', label: `From ${formatted}`, original: null };
    }

    // Single variant logic
    const variant = product.variants[0];
    const hasSale = variant.sale_price_in_cents !== null;
    return {
      type: 'single',
      label: hasSale ? variant.sale_price_formatted : variant.price_formatted,
      original: hasSale ? variant.price_formatted : null
    };
  }, [product.variants]);

  const status = useMemo(() => {
    // 1. Sold Logic: Explicitly out of stock (inventory managed and <= 0)
    // For lists, we check if ALL variants are sold out
    const allVariantsSoldOut = product.variants.every(v => 
      v.manage_inventory && v.inventory_quantity !== null && v.inventory_quantity <= 0
    );

    if (allVariantsSoldOut) {
      return 'Sold';
    }
    
    // 2. Inactive Logic
    if (!product.purchasable) {
      return 'Inactive';
    }
    
    // 3. Active Logic
    return 'Active';
  }, [product.purchasable, product.variants]);

  const isSold = status === 'Sold';
  const isInactive = status === 'Inactive';
  const isUnavailable = isSold || isInactive;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.05 }}
    >
      <Link to={`/product/${product.id}`}>
        <div className="group cursor-pointer">
          <div className="overflow-hidden mb-4 shadow-lg relative bg-gray-100">
            <img
              src={product.image || placeholderImage}
              alt={product.title}
              className={`w-full h-96 object-cover transition-transform duration-500 ${!isUnavailable ? 'group-hover:scale-105' : ''} ${isUnavailable ? 'grayscale-[0.5] opacity-90' : ''}`}
            />
            
            {/* Unavailable Status Overlay (Sold / Inactive) */}
            {isUnavailable && (
              <div className="absolute inset-0 bg-[#1A1A1A]/30 flex items-center justify-center z-20 backdrop-blur-[2px]">
                <div className="border border-[#F5F5DC]/80 p-2 transform -rotate-12 transition-transform group-hover:rotate-0 duration-500">
                    <span className="block font-serif text-2xl uppercase tracking-[0.25em] text-[#F5F5DC] bg-[#1A1A1A] px-8 py-3 whitespace-nowrap shadow-xl">
                    {status}
                    </span>
                </div>
              </div>
            )}

            {/* Active Status Badge */}
            {!isUnavailable && (
               <div className="absolute top-4 left-4 z-10">
                <span className="font-sans text-xs uppercase tracking-wider text-[#1A1A1A] bg-[#C9AB81] px-3 py-1 font-medium shadow-sm">
                  Active
                </span>
              </div>
            )}

            {/* Product Ribbon Text */}
            {!isUnavailable && product.ribbon_text && (
               <div className="absolute top-14 left-4 z-10">
                <span className="font-sans text-xs uppercase tracking-wider text-[#1A1A1A] bg-[#F5F5DC] px-3 py-1 font-medium shadow-sm">
                  {product.ribbon_text}
                </span>
              </div>
            )}
            
            {/* Sale Badge */}
             {!isUnavailable && product.variants.some(v => v.sale_price_in_cents !== null) && (
               <div className="absolute top-4 right-4 z-10">
                <span className="font-sans text-xs uppercase tracking-wider text-[#F5F5DC] bg-[#C9AB81] px-3 py-1 font-medium shadow-sm">
                  Sale
                </span>
              </div>
            )}
          </div>
          
          <h3 className="font-serif text-2xl font-light text-[#1A1A1A] mb-2 group-hover:text-[#C9AB81] transition-colors">
            {product.title}
          </h3>
          <p className="font-sans text-sm text-gray-600 mb-2 line-clamp-2">
            {product.subtitle || product.title}
          </p>
          
          <div className="flex items-center gap-3">
             {isUnavailable ? (
                <p className="font-sans text-lg text-[#C9AB81] font-medium opacity-80 italic">
                  {status === 'Sold' ? 'Sold Out' : 'Currently Unavailable'}
                </p>
             ) : (
               <>
                <p className="font-sans text-lg text-[#C9AB81] font-medium">
                  {priceDisplay?.label}
                </p>
                {priceDisplay?.original && (
                  <p className="font-sans text-sm text-gray-400 line-through">
                    {priceDisplay.original}
                  </p>
                )}
               </>
             )}
          </div>
        </div>
      </Link>
    </motion.div>
  );
};

const ProductsList = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const fetchProductsWithQuantities = async () => {
      try {
        setLoading(true);
        setError(null);

        const productsResponse = await getProducts();

        if (productsResponse.products.length === 0) {
          setProducts([]);
          return;
        }

        const productIds = productsResponse.products.map(product => product.id);

        const quantitiesResponse = await getProductQuantities({
          fields: 'inventory_quantity',
          product_ids: productIds
        });

        const variantQuantityMap = new Map();
        quantitiesResponse.variants.forEach(variant => {
          variantQuantityMap.set(variant.id, variant.inventory_quantity);
        });

        const productsWithQuantities = productsResponse.products.map(product => ({
          ...product,
          variants: product.variants.map(variant => ({
            ...variant,
            inventory_quantity: variantQuantityMap.get(variant.id) ?? variant.inventory_quantity
          }))
        }));

        setProducts(productsWithQuantities);
      } catch (err) {
        setError(err.message || 'Failed to load products');
      } finally {
        setLoading(false);
      }
    };

    fetchProductsWithQuantities();
  }, []);

  const filteredProducts = useMemo(() => {
    if (!searchQuery) return products;
    return products.filter(product => 
      product.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (product.subtitle && product.subtitle.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  }, [products, searchQuery]);

  if (loading) {
    return (
      <div className="flex justify-center items-center py-32">
        <Loader2 className="h-12 w-12 text-[#C9AB81] animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-20">
         <p className="text-red-500 font-sans">Unable to load artwork: {error}</p>
      </div>
    );
  }

  return (
    <div>
      {/* Search Bar */}
      <div className="mb-12 relative max-w-md mx-auto">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <input
          type="text"
          className="block w-full pl-10 pr-3 py-3 border-b border-[#C9AB81]/30 rounded-none leading-5 bg-transparent placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:border-[#C9AB81] transition-colors font-sans text-lg"
          placeholder="Search artwork by title..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {filteredProducts.length === 0 ? (
         <div className="text-center py-20">
          <p className="font-serif text-2xl text-gray-400">
            {products.length === 0 ? "No artwork currently available." : "No artwork found matching your search."}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {filteredProducts.map((product, index) => (
            <ProductCard key={product.id} product={product} index={index} />
          ))}
        </div>
      )}
    </div>
  );
};

export default ProductsList;