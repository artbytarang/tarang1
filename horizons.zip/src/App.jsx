import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import ShoppingCart from '@/components/ShoppingCart';
import Home from '@/pages/Home';
import About from '@/pages/About';
import Gallery from '@/pages/Gallery';
import Shop from '@/pages/Shop';
import ProductDetail from '@/pages/ProductDetail';
import Cart from '@/pages/Cart';
import Checkout from '@/pages/Checkout';
import Commissions from '@/pages/Commissions';
import Contact from '@/pages/Contact';
import Success from '@/pages/Success';
import PrivacyPolicy from '@/pages/PrivacyPolicy';
import TermsConditions from '@/pages/TermsConditions';
import ReturnsShipping from '@/pages/ReturnsShipping';
import { Toaster } from '@/components/ui/toaster';
import { CartProvider } from '@/hooks/useCart';

function App() {
  return (
    <CartProvider>
      <Router>
        <Helmet>
          <link rel="preconnect" href="https://fonts.googleapis.com" />
          <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
          <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet" />
        </Helmet>
        <div className="min-h-screen bg-[#1E1E1E] text-[#F5F5DC]">
          <Navigation />
          <ShoppingCart />
          <Routes>
            <Route path="/" element={<Home />} />
            {/* Renamed About page to The Artist, keeping redirect for legacy links */}
            <Route path="/about" element={<Navigate to="/the-artist" replace />} />
            <Route path="/the-artist" element={<About />} />
            <Route path="/gallery" element={<Gallery />} />
            <Route path="/shop" element={<Shop />} />
            <Route path="/product/:id" element={<ProductDetail />} />
            <Route path="/cart" element={<Cart />} />
            <Route path="/checkout" element={<Checkout />} />
            <Route path="/success" element={<Success />} />
            <Route path="/commissions" element={<Commissions />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/privacy-policy" element={<PrivacyPolicy />} />
            <Route path="/terms-conditions" element={<TermsConditions />} />
            <Route path="/returns-shipping" element={<ReturnsShipping />} />
          </Routes>
          <Footer />
          <Toaster />
        </div>
      </Router>
    </CartProvider>
  );
}

export default App;